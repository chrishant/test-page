(function () {

   /* ==================================================
      🔐 AUTHENTICATION SYSTEM
   ================================================== */

   async function verifyKey() {

      const STORAGE = "bk_auth_hash";

      let hash = localStorage.getItem(STORAGE);

      // ask only if not stored
      if (!hash) {

         const key = prompt("Enter BK Assistant Access Key:");
         if (!key) return false;

         const buf = await crypto.subtle.digest(
            "SHA-256",
            new TextEncoder().encode(key)
         );

         hash = [...new Uint8Array(buf)]
            .map(b => b.toString(16).padStart(2, "0"))
            .join("");
      }


      // ALWAYS VALIDATE WITH SERVER
      const res = await fetch(
         "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/HASH-KEY/keys.json",
         { cache: "no-store" }
      );

      if (!res.ok) {
         alert("❌ Key server unreachable");
         return false;
      }

      const db = await res.json();

      const today = new Date();

      const valid = db.keys.find(k =>
         k.hash === hash &&
         k.active &&
         new Date(k.expiry) >= today
      );

      if (!valid) {

         localStorage.removeItem(STORAGE);

         alert("❌ Access revoked or expired");

         return false;

      }

      // store hash if new
      localStorage.setItem(STORAGE, hash);

      return true;

   }


   /* ==================================================
      HEADER BUTTON
   ================================================== */

   const header = document.querySelector(
      "body > div:nth-child(1) > div:nth-child(5) > div > div > div > div:nth-child(1) > div > ul:nth-child(2)"
   );

   if (!header) {
      console.log("❌ Header container not found");
      return;
   }

   if (document.querySelector("#bom_auto_btn")) return;

   const li = document.createElement("li");

   li.innerHTML = `
<a class="btn btn-success"
id="bom_auto_btn"
style="margin-left:6px;">
BOM AUTO
</a>
`;

   header.appendChild(li);

   console.log("✅ BOM AUTO button added");


   /* ==================================================
      BUTTON CLICK
   ================================================== */

   document
      .getElementById("bom_auto_btn")
      .addEventListener("click", async function () {

         if (!(await verifyKey())) return;

         console.log("🚀 BOM automation started");

         (async function () {

            /* ==================================================
               HELPER
            ================================================== */

            function wait(ms) {
               return new Promise(r => setTimeout(r, ms));
            }


            /* ==================================================
               DETECT ACTIVE TAB
            ================================================== */

            function getActiveTab() {

               const tabs = document.querySelectorAll(".tabNew a");

               for (const tab of tabs) {

                  if (
                     !tab.classList.contains("ng-hide") &&
                     tab.style.backgroundColor.includes("lightgray")
                  ) {
                     return tab.innerText.trim();
                  }

               }

               return null;

            }

            const activeTab = getActiveTab();

            if (!activeTab) {

               console.log("❌ No active tab detected");

               return;

            }

            console.log("🎯 Active Tab:", activeTab);


            /* ==================================================
               CLICK BOM ITEM CREATION
            ================================================== */

            const btn = document.querySelector(
               'a[ng-click="BomItemCreation($event)"]'
            );

            if (!btn) {

               console.log("❌ BomItemCreation button not found");

               return;

            }

            btn.click();

            console.log("🚀 BomItemCreation Clicked");


            /* ==================================================
               WAIT MODAL
            ================================================== */

            await wait(1000);

            const modal = document.querySelector(
               "div.modal.fade.ng-isolate-scope.in"
            );

            if (!modal) {

               console.log("❌ Modal not found");

               return;

            }

            console.log("✅ Modal detected");


            /* ==================================================
               OPEN ITEM GROUP DROPDOWN
            ================================================== */

            const dropdown = modal.querySelector(
               "#item_group_type .dropdown-toggle"
            );

            if (!dropdown) {

               console.log("❌ Item Group dropdown not found");

               return;

            }

            dropdown.click();

            console.log("🟡 Item Group dropdown opened");

            await wait(400);


            /* ==================================================
               SEARCH ITEM GROUP
            ================================================== */

            const searchInput = document.querySelector(
               ".dropdown-menu input[ng-model='searchTerm']"
            );

            if (!searchInput) {

               console.log("❌ Search input not found");

               return;

            }

            searchInput.value = activeTab;

            searchInput.dispatchEvent(
               new Event("input", { bubbles: true })
            );

            searchInput.dispatchEvent(
               new Event("keyup", { bubbles: true })
            );

            console.log("⌨️ Search triggered");

            await wait(700);


            /* ==================================================
               SELECT ITEM GROUP
            ================================================== */

            const options = document.querySelectorAll(
               ".dropdown-menu ul li a"
            );

            const match = [...options].find(
               o => o.innerText.trim().toLowerCase() === activeTab.toLowerCase()
            );

            if (match) {

               match.click();

               console.log("✅ Item Group selected:", activeTab);

            } else {

               console.log("❌ Matching option not found");

            }

         })();

      });

})();