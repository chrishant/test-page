function verifyKey() {
  const STORAGE = "bk_auth_hash";

  let hash = localStorage.getItem(STORAGE);

  function validateWithServer(hash) {
    // ALWAYS VALIDATE WITH SERVER
    return fetch(
      "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/HASH-KEY/keys.json",
      { cache: "no-store" },
    ).then((res) => {
      if (!res.ok) {
        alert("❌ Key server unreachable");
        return false;
      }

      return res.json().then((db) => {
        const today = new Date();

        const valid = db.keys.find(
          (k) => k.hash === hash && k.active && new Date(k.expiry) >= today,
        );

        if (!valid) {
          localStorage.removeItem(STORAGE);

          alert("❌ Access revoked or expired");

          return false;
        }

        // store hash if new
        localStorage.setItem(STORAGE, hash);

        return true;
      });
    });
  }

  // ask only if not stored
  if (!hash) {
    const key = prompt("Enter BK Assistant Access Key:");
    if (!key) return Promise.resolve(false);

    return crypto.subtle
      .digest("SHA-256", new TextEncoder().encode(key))
      .then((buf) => {
        hash = [...new Uint8Array(buf)]
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("");

        return validateWithServer(hash);
      });
  }

  return validateWithServer(hash);
}
/* ==================================================
   HEADER BUTTON INJECTION
================================================== */

function waitForHeader() {
  return new Promise((resolve) => {
    const timer = setInterval(() => {
      const header = document.querySelector(
        "body > div:nth-child(1) > div:nth-child(5) > div > div > div > div > ul:nth-child(2)",
      );

      if (header) {
        clearInterval(timer);
        resolve(header);
      }
    }, 200);
  });
}
function waitForIdle(options = {}) {
  const { timeout = 15000, checkLoader = true, checkAngular = true } = options;

  const start = Date.now();

  function checkOnce() {
    let isIdle = true;

    // 🔹 1. Angular HTTP requests
    if (checkAngular && window.angular) {
      try {
        const el = document.querySelector("[ng-app]") || document.body;
        const injector = angular.element(el).injector();

        if (injector) {
          const $http = injector.get("$http");

          if ($http.pendingRequests.length > 0) {
            isIdle = false;
          }
        }
      } catch {}
    }

    // 🔹 2. Loader detection (generic)
    if (checkLoader) {
      const loader = [...document.querySelectorAll("div")].find(
        (el) =>
          el.innerText && el.innerText.toLowerCase().includes("please wait"),
      );

      if (loader && loader.offsetParent !== null) {
        isIdle = false;
      }
    }

    // 🔹 3. Small stability delay (digest/render)
    if (isIdle) {
      return new Promise((r) => setTimeout(r, 150)).then(() => true);
    }

    if (Date.now() - start > timeout) {
      console.warn("waitForIdle timeout");
      return Promise.resolve(false);
    }

    return new Promise((r) => setTimeout(r, 100)).then(checkOnce);
  }

  return checkOnce();
}
waitForHeader().then((header) => {
  if (document.querySelector("#bk_auto_receiving")) return;

  const li = document.createElement("li");

  li.innerHTML = `
        <a class="btn btn-warning"
           id="bk_auto_receiving"
           style="margin-left:6px;">
           📥 Auto Receiving
        </a>
    `;

  header.appendChild(li);

  console.log("✅ Receiving button injected");

  document
    .querySelector("#bk_auto_receiving")
    .addEventListener("click", runReceivingAutomation);
});

// ===============================
// RECEIVING SCRIPT RUNNER
// ===============================

function runReceivingAutomation() {
  console.log("🚀 Starting Receiving Automation");

  return verifyKey().then((ok) => {
    if (!ok) return;
    return runReceivingScript();
  });
}

// 🔽 FULL RECEIVING SCRIPT
function runReceivingScript() {
  if (!location.href.includes("#/procurement/receiving")) {
    throw new Error("❌ Not on Receiving screen");
  }

  // Sentinel used to short-circuit the rest of the chain, equivalent to
  // an early `return;` inside the original async function.
  const STOP = Symbol("stop");

  // ===============================
  // 0️⃣ COLLECT ALL USER INPUT UP FRONT
  // ===============================
  // Every prompt() that doesn't depend on live app state is asked here,
  // before the script touches the page at all. A Cancel on any of these
  // now bails out immediately with zero side effects, instead of
  // discovering the user backed out halfway through the automation.
  //
  // The "Add Charges" decision still has to wait until Section 7️⃣, since
  // whether charges are even needed depends on values read from the page
  // after the gate entry loads — but that step is now click-based (see
  // showChargeOptionsPicker below), so it doesn't need typing either.

  const supplierAliasMap = {
    imm: "INTERNATIONAL TRIMMINGS",
    itl: "INTERNATIONAL TRIMMINGS",
  };

  const supplierInput = prompt("Enter Supplier Alias or Name:");
  if (!supplierInput) return Promise.resolve();

  const supplier =
    supplierAliasMap[supplierInput.toLowerCase().trim()] || supplierInput;

  const gateValue = prompt("Enter Gate Entry Number:");
  if (!gateValue) return Promise.resolve();

  const qtyInputRaw = prompt(
    "Enter Expected Quantity (you can use +, -, *, /):",
  );
  const expectedQty = evaluateExpression(qtyInputRaw);

  if (expectedQty === null || isNaN(expectedQty)) {
    alert("Invalid quantity input");
    return Promise.resolve();
  }

  const amountInput = prompt("Enter Expected Amount:");
  if (!qtyInputRaw || !amountInput) return Promise.resolve();

  const expectedAmount = parseFloat(amountInput);

  function wait(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function waitForPageLoad() {
    return new Promise((resolve) => {
      if (document.readyState === "complete") resolve();
      else window.addEventListener("load", resolve);
    });
  }

  // Generic replacement for the repeated
  // `for (let i = 0; i < N; i++) { ...check...; if (ok) break; await wait(ms); }`
  // polling loops in the original script.
  //
  // IMPORTANT: a single successful check is not proof the element/state is
  // actually settled — in an Angular app an element can exist (or a button
  // can look "enabled") for one tick and then get re-rendered or re-bound
  // on the next digest cycle. To avoid clicking something that's still
  // mid-render, this requires the check to pass on `requiredStableChecks`
  // *consecutive* polls, spaced `intervalMs` apart, before it's trusted.
  function pollFor(
    maxAttempts,
    intervalMs,
    getFn,
    isValidFn,
    requiredStableChecks = 2,
  ) {
    isValidFn = isValidFn || ((v) => !!v);

    let consecutive = 0;
    let lastGoodVal = null;

    function attempt(n) {
      const val = getFn();

      if (isValidFn(val)) {
        consecutive++;
        lastGoodVal = val;
      } else {
        consecutive = 0;
        lastGoodVal = null;
      }

      if (consecutive >= requiredStableChecks) {
        return Promise.resolve(lastGoodVal);
      }

      if (n >= maxAttempts) {
        // Ran out of attempts — return whatever we last saw (possibly
        // null/falsy) so callers can still detect failure explicitly.
        return Promise.resolve(lastGoodVal || val);
      }

      return wait(intervalMs).then(() => attempt(n + 1));
    }

    return attempt(1);
  }

  function evaluateExpression(input) {
    if (!input) return null;

    // allow only numbers + math operators
    if (!/^[0-9+\-*/().\s]+$/.test(input)) {
      alert("Invalid expression");
      return null;
    }

    try {
      return Function(`"use strict"; return (${input})`)();
    } catch {
      alert("Error in expression");
      return null;
    }
  }
  function waitForModal(checkFn, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      let consecutive = 0;

      const interval = setInterval(() => {
        const modal = document.body.lastElementChild;

        // Require 2 consecutive hits before trusting the modal is
        // actually finished mounting/rendering its contents, not just
        // present for a single tick.
        if (modal && checkFn(modal)) {
          consecutive++;
          if (consecutive >= 2) {
            clearInterval(interval);
            resolve(modal);
            return;
          }
        } else {
          consecutive = 0;
        }

        if (Date.now() - start > timeout) {
          clearInterval(interval);
          reject("Modal not detected.");
        }
      }, 100);
    });
  }

  function showAlert(message, type = "success", duration = 7000) {
    let container = document.getElementById("centerTopValidationAlert");

    if (!container) {
      container = document.createElement("div");
      container.id = "centerTopValidationAlert";
      container.style.position = "fixed";
      container.style.top = "70px";
      container.style.left = "50%";
      container.style.transform = "translateX(-50%)";
      container.style.zIndex = "999999";
      container.style.pointerEvents = "none";
      document.body.appendChild(container);
    }

    const alertDiv = document.createElement("div");
    alertDiv.innerText = message;

    alertDiv.style.padding = "14px 26px";
    alertDiv.style.borderRadius = "10px";
    alertDiv.style.fontWeight = "600";
    alertDiv.style.fontSize = "14px";
    alertDiv.style.fontFamily = "Segoe UI, sans-serif";
    alertDiv.style.color = "white";
    alertDiv.style.textAlign = "center";
    alertDiv.style.boxShadow = "0 12px 30px rgba(0,0,0,0.25)";
    alertDiv.style.transform = "translateY(-20px)";
    alertDiv.style.opacity = "0";
    alertDiv.style.transition = "all 0.35s ease";
    alertDiv.style.background = type === "success" ? "#1e7e34" : "#c82333";

    container.appendChild(alertDiv);

    requestAnimationFrame(() => {
      alertDiv.style.transform = "translateY(0)";
      alertDiv.style.opacity = "1";
    });

    setTimeout(() => {
      alertDiv.style.opacity = "0";
      alertDiv.style.transform = "translateY(-20px)";
      setTimeout(() => alertDiv.remove(), 350);
    }, duration);
  }

  // ===============================
  // 🛡️ ERROR-HANDLING HELPERS
  // ===============================
  // Centralizes the "data isn't there" failure path so every step fails
  // the same predictable way — a clear on-screen message, then a clean
  // stop — instead of an uncaught "Cannot read properties of null/
  // undefined" crash that just dies silently in the console.

  // Query for a required element. Returns it, or shows an alert and
  // returns null if it's missing.
  function requireElement(root, selector, label) {
    let el;
    try {
      el = (root || document).querySelector(selector);
    } catch (err) {
      showAlert(`${label}: bad selector (${err.message}).`, "error", 6000);
      return null;
    }
    if (!el) {
      showAlert(`${label} not found on the page.`, "error", 6000);
      return null;
    }
    return el;
  }

  // Read an Angular scope off an element. Returns it, or shows an alert
  // and returns null if Angular isn't present, the element is missing,
  // or the element simply isn't bound to a scope.
  function requireScope(el, label) {
    if (!el) {
      showAlert(
        `${label}: element missing, can't read its data.`,
        "error",
        6000,
      );
      return null;
    }
    if (typeof angular === "undefined" || !window.angular) {
      showAlert(
        "AngularJS not detected on this page — automation can't continue.",
        "error",
        6000,
      );
      return null;
    }
    let scope;
    try {
      scope = angular.element(el).scope();
    } catch (err) {
      showAlert(
        `${label}: error reading Angular scope (${err.message}).`,
        "error",
        6000,
      );
      return null;
    }
    if (!scope) {
      showAlert(
        `${label}: could not read Angular scope (not bound yet?).`,
        "error",
        6000,
      );
      return null;
    }
    return scope;
  }

  // Parse a number out of arbitrary DOM text (e.g. "Qty: 42.5 pcs"),
  // instead of assuming a regex match will always succeed.
  function extractNumber(text, label) {
    const match = (text || "").match(/([\d.]+)/);
    if (!match) {
      showAlert(
        `${label}: couldn't find a number in "${text}".`,
        "error",
        6000,
      );
      return null;
    }
    const num = parseFloat(match[1]);
    if (isNaN(num)) {
      showAlert(`${label}: parsed value is not a valid number.`, "error", 6000);
      return null;
    }
    return num;
  }

  function parseAmount(rawValue, label) {
    if (rawValue === null || rawValue === undefined || rawValue === "") {
      showAlert(`${label}: value is empty.`, "error", 6000);
      return null;
    }
    const num = parseFloat(String(rawValue).replace(/,/g, ""));
    if (isNaN(num)) {
      showAlert(
        `${label}: "${rawValue}" is not a valid amount.`,
        "error",
        6000,
      );
      return null;
    }
    return num;
  }

  function applyBalanceRemarkLogic() {
    function parseValue(el) {
      if (!el) return 0;
      return parseFloat(el.innerText.replace(/,/g, "").trim()) || 0;
    }

    const grid = document.querySelector(".ui-grid-render-container-body");
    if (!grid) {
      alert("Grid not found.");
      return false;
    }

    const rows = grid.querySelectorAll(".ui-grid-row");
    let remarkRequired = false;
    let affectedRows = [];

    rows.forEach((row, i) => {
      const balanceEl = row.querySelector(
        ".ui-grid-coluiGrid-001G .ui-grid-cell-contents",
      );
      const receiveEl = row.querySelector(
        ".ui-grid-coluiGrid-001J .ui-grid-cell-contents",
      );
      const poEl = row.querySelector(
        ".ui-grid-coluiGrid-001K .ui-grid-cell-contents",
      );

      const balance = parseValue(balanceEl);
      const receive = parseValue(receiveEl);
      const po = parseValue(poEl);

      // 🔴 RULE 1
      if (balance < 0 && po > receive) {
        remarkRequired = true;
        affectedRows.push(i + 1);
      }
    });

    const remarkBox = document.querySelector("#remarks");

    if (!remarkBox) {
      alert("Remarks field not found.");
      return false;
    }

    if (remarkRequired) {
      const remarkText =
        `Over receipt adjustment detected in row(s): ${affectedRows.join(", ")}. ` +
        `Balance quantity is negative while PO quantity exceeds receiving quantity.`;

      // Update Angular model properly
      const scope = requireScope(remarkBox, "Remarks field");
      if (!scope || !scope.main_model) {
        showAlert("Could not set remarks — model not ready.", "error", 6000);
        return false;
      }

      scope.$apply(function () {
        scope.main_model.remarks = remarkText;
      });

      console.log("Remark added.");
    }

    return true;
  }

  // ===============================
  // 🔹 CHARGE OPTIONS PICKER (click-based, no typing)
  // ===============================
  // Shown when Qty/Receive/Bill don't match. Offers one-click preset
  // charges, a live-computed "exact difference" option, a Custom
  // fallback (old type-it-in flow), and a Skip.
  //
  // Edit CHARGE_PRESETS to match the charge type/amount combos you use
  // most often — each becomes its own button, e.g. "FC 450", "FC 800".
  function showChargeOptionsPicker(diffAmount) {
    const CHARGE_PRESETS = [
      { alias: "fc", amount: 450 },
      { alias: "fc", amount: 800 },
    ];

    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.style.position = "fixed";
      overlay.style.inset = "0";
      overlay.style.background = "rgba(0,0,0,0.45)";
      overlay.style.zIndex = "999999";
      overlay.style.display = "flex";
      overlay.style.alignItems = "center";
      overlay.style.justifyContent = "center";
      overlay.style.fontFamily = "Segoe UI, sans-serif";

      const box = document.createElement("div");
      box.style.background = "#fff";
      box.style.borderRadius = "12px";
      box.style.padding = "22px";
      box.style.minWidth = "300px";
      box.style.boxShadow = "0 16px 40px rgba(0,0,0,0.35)";

      const title = document.createElement("div");
      title.innerText = "Values don't match. Add a charge:";
      title.style.fontWeight = "700";
      title.style.fontSize = "15px";
      title.style.marginBottom = "6px";
      box.appendChild(title);

      const subtitle = document.createElement("div");
      subtitle.innerText = `Difference: ${diffAmount.toFixed(2)}`;
      subtitle.style.fontSize = "12px";
      subtitle.style.color = "#666";
      subtitle.style.marginBottom = "14px";
      box.appendChild(subtitle);

      function close(result) {
        document.body.removeChild(overlay);
        resolve(result);
      }

      function makeButton(label, bg, onClick) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.innerText = label;
        btn.style.display = "block";
        btn.style.width = "100%";
        btn.style.margin = "6px 0";
        btn.style.padding = "10px 14px";
        btn.style.border = "none";
        btn.style.borderRadius = "8px";
        btn.style.fontSize = "14px";
        btn.style.fontWeight = "600";
        btn.style.color = "#fff";
        btn.style.background = bg;
        btn.style.cursor = "pointer";
        btn.onclick = onClick;
        box.appendChild(btn);
        return btn;
      }

      CHARGE_PRESETS.forEach((p) => {
        makeButton(`${p.alias.toUpperCase()} ${p.amount}`, "#1e7e34", () =>
          close({ alias: p.alias, amount: p.amount, notTaxable: false }),
        );
      });

      if (diffAmount > 0) {
        makeButton(`FC ${diffAmount.toFixed(2)} (exact diff)`, "#0d6efd", () =>
          close({
            alias: "fc",
            amount: diffAmount.toFixed(2),
            notTaxable: false,
          }),
        );
      }

      makeButton("Custom...", "#6c757d", () => close("custom"));
      makeButton("Skip / Cancel", "#c82333", () => close(null));

      overlay.appendChild(box);
      document.body.appendChild(overlay);
    });
  }

  function runAddChargesScript(preset) {
    var addBtn = document.querySelector(
      "#detail_collapsible_panel_open_popup_receive_other_charges_dt",
    );

    if (!addBtn) {
      console.log("Add Other Charges button not found.");
      return Promise.resolve(false);
    }

    addBtn.click();
    console.log("Opening Additional Charges modal...");

    return wait(400).then(() => {
      var typeDropdownList = document.querySelectorAll("#account_id");
      var typeDropdown = typeDropdownList[typeDropdownList.length - 1];

      if (!typeDropdown) {
        console.log("Charge Type dropdown not found.");
        return false;
      }

      var modal = typeDropdown.closest(".modal-content");

      const chargeAliasMap = {
        bc: "BANK CHARGES",
        fc: "FREIGHT AND CARTAGE",
        disc: "DISCOUNT",
      };

      var cleaned, isNotTaxable, chargeType, amount;

      // `preset` comes from showChargeOptionsPicker: either a
      // { alias, amount, notTaxable } object from a one-click option,
      // or the string "custom" (falls back to the old type-it-in flow).
      if (preset && preset !== "custom") {
        cleaned = String(preset.alias).trim().toLowerCase();
        isNotTaxable = !!preset.notTaxable;
        chargeType = chargeAliasMap[cleaned] || cleaned.toUpperCase();
        amount = String(preset.amount);
      } else {
        var userInput = prompt("Enter Charge Type Alias (bc, fcn, discn etc):");
        if (!userInput) return false;

        cleaned = userInput.trim().toLowerCase();
        isNotTaxable = cleaned.endsWith("n");

        if (isNotTaxable) {
          cleaned = cleaned.slice(0, -1);
        }

        chargeType = chargeAliasMap[cleaned] || cleaned.toUpperCase();

        amount = prompt("Enter Charge Amount:");
        if (!amount) return false;
      }

      typeDropdown.querySelector(".dropdown-toggle").click();

      return wait(200).then(() => {
        var searchInput = typeDropdown.querySelector("input[type='text']");
        if (searchInput) {
          var searchScope = angular.element(searchInput).scope();
          searchScope.$apply(function () {
            searchScope.searchTerm = chargeType;
          });
        }

        return wait(500).then(() => {
          var options = typeDropdown.querySelectorAll("ul li a");

          var target = [...options].find(
            (opt) =>
              opt.innerText.trim().toLowerCase() === chargeType.toLowerCase(),
          );

          if (!target) {
            console.log("Charge type not found in dropdown.");
            return false;
          }

          target.click();

          return wait(200).then(() => {
            var amountInputs = modal.querySelectorAll("#charge_value");
            var amountInput = amountInputs[amountInputs.length - 1];
            var scope = angular.element(amountInput).scope();

            scope.$apply(function () {
              scope.popup_model.charge_value = amount;
            });

            return wait(200).then(() => {
              function finishAddCharge() {
                var buttons = modal.querySelectorAll("button");

                var okCloseBtn = [...buttons].find(
                  (btn) => btn.innerText.trim().toLowerCase() === "ok & close",
                );

                if (!okCloseBtn) {
                  console.log("Ok & Close button not found.");
                  return false;
                }

                okCloseBtn.click();

                console.log("Additional Charge added successfully.");
                return true;
              }

              if (isNotTaxable) {
                var taxDropdownList = modal.querySelectorAll("#is_tax");
                var taxDropdown = taxDropdownList[taxDropdownList.length - 1];

                taxDropdown.querySelector(".dropdown-toggle").click();

                return wait(200).then(() => {
                  var taxOptions = taxDropdown.querySelectorAll("ul li a");

                  var noOption = [...taxOptions].find(
                    (opt) => opt.innerText.trim().toLowerCase() === "no",
                  );

                  if (noOption) noOption.click();

                  return wait(200).then(finishAddCharge);
                });
              }

              return finishAddCharge();
            });
          });
        });
      });
    });
  }

  // ===============================
  // 1️⃣ SUPPLIER SELECTION
  // ===============================
  // (supplier, gate entry, expected qty/amount were already collected
  // above in Section 0️⃣)

  document.querySelector("#search_party").click();

  return (
    waitForModal((modal) => modal.querySelector(".ui-grid-filter-input"))
      .then((supplierModal) => {
        const filterInput = supplierModal.querySelector(
          ".ui-grid-filter-input",
        );
        const filterScope = angular.element(filterInput).scope();

        filterScope.$apply(function () {
          filterScope.colFilter.term = supplier;
        });

        return wait(600).then(() => {
          const rows = supplierModal.querySelectorAll(".ui-grid-row");
          if (!rows.length) return STOP;

          rows[0]
            .querySelector(".ui-grid-selection-row-header-buttons")
            .click();

          return wait(150);
        });
      })

      // ===============================
      // 2️⃣ RECEIVE TYPE
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        const recvDropdown = document.querySelector("#recv_type");
        recvDropdown.querySelector(".dropdown-toggle").click();

        return wait(100).then(() => {
          const recvOptions = recvDropdown.querySelectorAll("ul li a");

          const recvTarget = [...recvOptions].find(
            (opt) => opt.innerText.trim().toLowerCase() === "material purchase",
          );

          if (!recvTarget) return STOP;

          recvTarget.click();
          return wait(800).then(() => waitForIdle());
        });
      })

      // ===============================
      // 3️⃣ OPEN GATE ENTRY
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        document.querySelector("#gate_record").click();
        return wait(800).then(() => waitForIdle());
      })

      // ===============================
      // 4️⃣ SELECT GATE ENTRY
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        wait(300).then(() => waitForIdle());
        const gateDropdown = document.querySelector("#gate_entry_id");
        gateDropdown.querySelector(".dropdown-toggle").click();
        return wait(100)
          .then(() =>
            pollFor(15, 500, () =>
              gateDropdown.querySelector(".custom-select-search input"),
            ),
          )
          .then((searchInput) => {
            if (!searchInput) return STOP;

            const gateScope = angular.element(searchInput).scope();
            waitForIdle();
            gateScope.$apply(function () {
              gateScope.colFilter.searchTerm = gateValue;
            });

            return wait(500).then(() => {
              const gateOptions = gateDropdown.querySelectorAll("ul li a");

              let match = [...gateOptions].find((opt) =>
                opt.innerText.toLowerCase().includes(gateValue.toLowerCase()),
              );

              if (!match && gateOptions.length) {
                match = gateOptions[0];
              }

              if (!match) return STOP;

              match.click();
              return wait(800).then(() => waitForIdle());
            });
          });
      })

      // ===============================
      // 5️⃣ SELECT ALL GRID
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        const buttons = document.querySelectorAll(
          ".ui-grid-selection-row-header-buttons",
        );

        if (buttons.length >= 3) {
          const gridScope = angular.element(buttons[2]).scope();
          gridScope.$apply(function () {
            gridScope.headerButtonClick();
          });
        }

        return wait(500).then(() => waitForIdle());
      })

      // ===============================
      // 6️⃣ CLICK OK & CLOSE
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        return waitForIdle().then(() =>
          pollFor(
            20,
            100,
            () => document.querySelector("#sub_screen_ok"),
            (btn) => btn && !btn.disabled,
          ),
        );
      })
      .then((okBtn) => {
        if (okBtn === STOP) return STOP;
        if (!okBtn) return STOP;

        okBtn.click();

        return wait(1500)
          .then(() => waitForPageLoad())
          .then(() => waitForIdle());
      })

      // ===============================
      // 7️⃣ VALIDATION
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        // expectedQty / expectedAmount were already collected up front
        // in Section 0️⃣ — nothing to prompt for here.

        const footer = document.querySelector(".settotalfooter");
        const receiveField = document.querySelector("#receive_amount");
        const billField = document.querySelector("#bill_amount");

        if (!footer || !receiveField || !billField) {
          showAlert("Validation fields not found.", "error");
          return STOP;
        }

        const actualQty = parseFloat(footer.innerText.match(/([\d\.]+)/)[1]);

        const receiveAmount = parseFloat(receiveField.value.replace(/,/g, ""));
        const billAmount = parseFloat(billField.value.replace(/,/g, ""));

        const qtyValid = Math.abs(expectedQty - actualQty) <= 1;

        function isWithinTolerance(actual) {
          const TOLERANCE = 1;
          return Math.abs(expectedAmount - actual) <= TOLERANCE;
        }

        const receiveValid = isWithinTolerance(receiveAmount);
        const billValid = isWithinTolerance(billAmount);

        const allValid = qtyValid && receiveValid && billValid;

        showAlert(
          `Qty:${qtyValid ? "✔" : "✖"} | Rec:${receiveValid ? "✔" : "✖"} | Bill:${billValid ? "✔" : "✖"}`,
          allValid ? "success" : "error",
          7000,
        );

        if (!allValid) {
          const diffAmount = Math.abs(
            Number((expectedAmount - billAmount).toFixed(2)),
          );

          return wait(800)
            .then(() => waitForPageLoad())
            .then(() => showChargeOptionsPicker(diffAmount))
            .then((choice) => {
              if (!choice) {
                showAlert("Process stopped due to mismatch.", "error", 5000);
                return STOP;
              }

              showAlert("Opening Add Charges...", "success", 4000);

              return runAddChargesScript(choice).then((added) => {
                if (!added) {
                  showAlert("Charges were not added.", "error", 5000);
                  return STOP;
                }

                // ✅ WAIT FOR SYSTEM TO RECALCULATE
                return wait(1200).then(() => {
                  // 🔁 RE-VALIDATE AGAIN
                  const newReceiveAmount = parseFloat(
                    document
                      .querySelector("#receive_amount")
                      .value.replace(/,/g, ""),
                  );

                  const newBillAmount = parseFloat(
                    document
                      .querySelector("#bill_amount")
                      .value.replace(/,/g, ""),
                  );

                  const newReceiveValid = isWithinTolerance(newReceiveAmount);
                  const newBillValid = isWithinTolerance(newBillAmount);

                  const newAllValid = newReceiveValid && newBillValid;

                  showAlert(
                    `After Charges → Rec:${newReceiveValid ? "✔" : "✖"} | Bill:${newBillValid ? "✔" : "✖"}`,
                    newAllValid ? "success" : "error",
                    6000,
                  );

                  if (!newAllValid) {
                    showAlert(
                      "Still not matching. Stopping process.",
                      "error",
                      6000,
                    );
                    return STOP;
                  }

                  // ✅ If valid now → DO NOT STOP
                  showAlert("Amounts matched. Continuing...", "success", 4000);
                  return true;
                });
              });
            });
        }

        return true;
      })

      // ===============================
      // 🔹 SELECT STORE
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        const storeDropdown = document.querySelector("#stores");
        if (!storeDropdown) {
          showAlert("Store dropdown not found.", "error");
          return STOP;
        }

        storeDropdown.querySelector(".dropdown-toggle").click();

        return wait(200).then(() => {
          const storeOptions = storeDropdown.querySelectorAll("ul li a");

          const storeMatch = [...storeOptions].find(
            (opt) => opt.innerText.trim().toLowerCase() === "acc store c-122",
          );

          if (!storeMatch) {
            showAlert("ACC. STORE C-122 not found.", "error");
            return STOP;
          }

          storeMatch.click();
          return wait(100).then(() => waitForIdle());
        });
      })

      // ===============================
      // DATA MATCHING SCRIPT + 🔹 CLICK APPLY
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        applyBalanceRemarkLogic();

        return pollFor(
          15,
          100,
          () => document.querySelector("#apply"),
          (btn) => btn && !btn.disabled,
        );
      })
      .then((applyBtn) => {
        if (applyBtn === STOP) return STOP;

        if (!applyBtn) {
          showAlert("Apply button not found.", "error");
          return STOP;
        }

        applyBtn.click();

        return wait(1000)
          .then(() => waitForPageLoad())
          .then(() => waitForIdle());
      })

      // ===============================
      // 8️⃣ ASK USER TO SAVE
      // ===============================
      .then((result) => {
        if (result === STOP) return STOP;

        const saveDecision = prompt(
          "All validations passed.\nType YES / Y / OK to Save:",
        );

        if (!saveDecision) {
          showAlert("Save Cancelled by User.", "error", 4000);
          return STOP;
        }

        const normalized = saveDecision.trim().toLowerCase();

        const acceptedInputs = ["yes", "y", "ok", "okay"];

        if (!acceptedInputs.includes(normalized)) {
          showAlert("Save Cancelled by User.", "error", 4000);
          return STOP;
        }

        // ===============================
        // 9️⃣ CLICK SAVE
        // ===============================
        return pollFor(
          20,
          100,
          () => document.querySelector("#Save"),
          (btn) => btn && !btn.disabled,
        );
      })
      .then((saveBtn) => {
        if (saveBtn === STOP) return;
        if (!saveBtn) return;

        saveBtn.click();
        showAlert("Record Saved Successfully ✔", "success", 6000);
      })
      .catch((err) => {
        console.error(err);
      })
  );
}
