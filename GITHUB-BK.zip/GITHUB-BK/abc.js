async function verifyKey() {
   
   document.title = "REC"
   const STORAGE = "bk_auth_hash";
   
   let hash = localStorage.getItem(STORAGE);
   
   // ask only if not stored
   if (!hash) {
      
      const key = prompt("Enter BK Assistant Access Key:");
      if (!key) return false;
      
      const buf = await crypto.subtle.digest(
         "SHA-256",
         new TextEncoder().encode(key)
      );
      
      hash = [...new Uint8Array(buf)]
      .map(b => b.toString(16).padStart(2, "0"))
         .join("");
      }


      // ALWAYS VALIDATE WITH SERVER
      const res = await fetch(
         "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/HASH-KEY/keys.json",
         { cache: "no-store" }
      );
      
      if (!res.ok) {
         alert("❌ Key server unreachable");
         return false;
      }
      
      const db = await res.json();
      
      const today = new Date();
      
      const valid = db.keys.find(k =>
         k.hash === hash &&
         k.active &&
         new Date(k.expiry) >= today
      );
      
      if (!valid) {
         
         localStorage.removeItem(STORAGE);
         
      alert("❌ Access revoked or expired");

      return false;

   }

   // store hash if new
   localStorage.setItem(STORAGE, hash);

   return true;

}
/* ==================================================
   HEADER BUTTON INJECTION & CLEANUP
================================================== */

function waitForHeader() {
   return new Promise(resolve => {

      const timer = setInterval(() => {

         const header = document.querySelector(
            "body > div:nth-child(1) > div:nth-child(5) > div > div > div > div > ul:nth-child(2)"
         );

         if (header) {
            clearInterval(timer);
            resolve(header);
         }

      }, 200);

   });
}

// 🔄 WE WRAP THE INJECTION LOGIC IN A REFRESHABLE FUNCTION
function initScript() {
   
   // 1. REMOVE the old button first if it exists
   const existingBtn = document.querySelector("#bk_auto_receiving");
   if (existingBtn) {
      existingBtn.closest('li').remove();
      console.log("🧹 Old button removed");
   }

   // 2. RE-INJECT the button
   waitForHeader().then(header => {

      const li = document.createElement("li");

      li.innerHTML = `
           <a class="btn btn-warning"
              id="bk_auto_receiving"
              style="margin-left:6px;">
              📥 Auto Receiving
           </a>
       `;

      header.appendChild(li);

      console.log("✅ Receiving button injected");

      document
         .querySelector("#bk_auto_receiving")
         .addEventListener("click", runReceivingAutomation);

   });
}

// 🎯 TARGET THE #New BUTTON FOR AUTOMATIC REFRESH
function bindNewButton() {
   const newBtn = document.querySelector("#New");
   if (newBtn && !newBtn.dataset.bkBound) {
      newBtn.dataset.bkBound = "true"; // Prevents multiple event listeners
      
      newBtn.addEventListener("click", () => {
         console.log("♻️ #New button clicked! Refreshing script...");
         
         // Give Angular 1 second to clear and rebuild the page before reinjecting
         setTimeout(() => {
            initScript();
         }, 1000);
      });
      console.log("✅ Refresh bound to #New button");
   }
}


async function waitForIdle(options = {}) {

   const {
      timeout = 15000,
      checkLoader = true,
      checkAngular = true
   } = options;

   const start = Date.now();

   while (true) {

      let isIdle = true;

      // 🔹 1. Angular HTTP requests
      if (checkAngular && window.angular) {
         try {
            const el = document.querySelector("[ng-app]") || document.body;
            const injector = angular.element(el).injector();

            if (injector) {
               const $http = injector.get("$http");

               if ($http.pendingRequests.length > 0) {
                  isIdle = false;
               }
            }
         } catch { }
      }

      // 🔹 2. Loader detection (generic)
      if (checkLoader) {
         const loader = [...document.querySelectorAll("div")]
            .find(el =>
               el.innerText &&
               el.innerText.toLowerCase().includes("please wait")
            );

         if (loader && loader.offsetParent !== null) {
            isIdle = false;
         }
      }

      // 🔹 3. Small stability delay (digest/render)
      if (isIdle) {
         await new Promise(r => setTimeout(r, 150));
         return true;
      }

      if (Date.now() - start > timeout) {
         console.warn("waitForIdle timeout");
         return false;
      }

      await new Promise(r => setTimeout(r, 100));
   }
}

// ===============================
// RECEIVING SCRIPT RUNNER
// ===============================

async function runReceivingAutomation() {

   console.log("🚀 Starting Receiving Automation");
   if (!(await verifyKey())) return;
   // 🔽 PASTE YOUR FULL RECEIVING SCRIPT BELOW
   // Remove only the outer wrapper: (async function(){ ... })();
   (async function () {
      if (!location.href.includes("#/procurement/receiving")) {
         throw new Error("❌ Not on Receiving screen");
      }
      function wait(ms) {
         return new Promise(r => setTimeout(r, ms));
      }
      function evaluateExpression(input) {

         if (!input) return null;

         // allow only numbers + math operators
         if (!/^[0-9+\-*/().\s]+$/.test(input)) {
            alert("Invalid expression");
            return null;
         }

         try {
            return Function(`"use strict"; return (${input})`)();
         } catch {
            alert("Error in expression");
            return null;
         }
      }
      function waitForModal(checkFn, timeout = 10000) {
         return new Promise((resolve, reject) => {
            const start = Date.now();
            const interval = setInterval(() => {
               const modal = document.body.lastElementChild;
               if (modal && checkFn(modal)) {
                  clearInterval(interval);
                  resolve(modal);
               }
               if (Date.now() - start > timeout) {
                  clearInterval(interval);
                  reject("Modal not detected.");
               }
            }, 100);
         });
      }

      function showAlert(message, type = "success", duration = 7000) {
         let container = document.getElementById("centerTopValidationAlert");

         if (!container) {
            container = document.createElement("div");
            container.id = "centerTopValidationAlert";
            container.style.position = "fixed";
            container.style.top = "70px";
            container.style.left = "50%";
            container.style.transform = "translateX(-50%)";
            container.style.zIndex = "999999";
            container.style.pointerEvents = "none";
            document.body.appendChild(container);
         }

         const alertDiv = document.createElement("div");
         alertDiv.innerText = message;

         alertDiv.style.padding = "14px 26px";
         alertDiv.style.borderRadius = "10px";
         alertDiv.style.fontWeight = "600";
         alertDiv.style.fontSize = "14px";
         alertDiv.style.fontFamily = "Segoe UI, sans-serif";
         alertDiv.style.color = "white";
         alertDiv.style.textAlign = "center";
         alertDiv.style.boxShadow = "0 12px 30px rgba(0,0,0,0.25)";
         alertDiv.style.transform = "translateY(-20px)";
         alertDiv.style.opacity = "0";
         alertDiv.style.transition = "all 0.35s ease";
         alertDiv.style.background =
            type === "success" ? "#1e7e34" : "#c82333";

         container.appendChild(alertDiv);

         requestAnimationFrame(() => {
            alertDiv.style.transform = "translateY(0)";
            alertDiv.style.opacity = "1";
         });

         setTimeout(() => {
            alertDiv.style.opacity = "0";
            alertDiv.style.transform = "translateY(-20px)";
            setTimeout(() => alertDiv.remove(), 350);
         }, duration);
      }
      function applyBalanceRemarkLogic() {

         function parseValue(el) {
            if (!el) return 0;
            return parseFloat(el.innerText.replace(/,/g, "").trim()) || 0;
         }

         const grid = document.querySelector(".ui-grid-render-container-body");
         if (!grid) {
            alert("Grid not found.");
            return false;
         }

         const rows = grid.querySelectorAll(".ui-grid-row");
         let remarkRequired = false;
         let affectedRows = [];

         rows.forEach((row, i) => {

            const balanceEl = row.querySelector(".ui-grid-coluiGrid-001G .ui-grid-cell-contents");
            const receiveEl = row.querySelector(".ui-grid-coluiGrid-001J .ui-grid-cell-contents");
            const poEl = row.querySelector(".ui-grid-coluiGrid-001K .ui-grid-cell-contents");

            const balance = parseValue(balanceEl);
            const receive = parseValue(receiveEl);
            const po = parseValue(poEl);

            // 🔴 RULE 1
            if (balance < 0 && po > receive) {
               remarkRequired = true;
               affectedRows.push(i + 1);
            }

         });

         const remarkBox = document.querySelector("#remarks");

         if (!remarkBox) {
            alert("Remarks field not found.");
            return false;
         }

         if (remarkRequired) {

            const remarkText =
               `Over receipt adjustment detected in row(s): ${affectedRows.join(", ")}. ` +
               `Balance quantity is negative while PO quantity exceeds receiving quantity.`;

            // Update Angular model properly
            const scope = angular.element(remarkBox).scope();
            scope.$apply(function () {
               scope.main_model.remarks = remarkText;
            });

            console.log("Remark added.");
         }

         return true;
      }
      // ===============================
      // 1️⃣ SUPPLIER SELECTION
      // ===============================

      const supplierAliasMap = {
         "imm": "INTERNATIONAL TRIMMINGS",
         "itl": "INTERNATIONAL TRIMMINGS"
      };

      const supplierInput = prompt("Enter Supplier Alias or Name:");
      if (!supplierInput) return;

      const supplier =
         supplierAliasMap[supplierInput.toLowerCase().trim()] || supplierInput;

      document.querySelector("#search_party").click();

      const supplierModal = await waitForModal(modal =>
         modal.querySelector(".ui-grid-filter-input")
      );

      const filterInput = supplierModal.querySelector(".ui-grid-filter-input");
      const filterScope = angular.element(filterInput).scope();

      filterScope.$apply(function () {
         filterScope.colFilter.term = supplier;
      });

      await wait(600);

      const rows = supplierModal.querySelectorAll(".ui-grid-row");
      if (!rows.length) return;

      rows[0]
         .querySelector(".ui-grid-selection-row-header-buttons")
         .click();

      await wait(150);

      // ===============================
      // 2️⃣ RECEIVE TYPE
      // ===============================

      const recvDropdown = document.querySelector("#recv_type");
      recvDropdown.querySelector(".dropdown-toggle").click();
      await wait(100);

      const recvOptions = recvDropdown.querySelectorAll("ul li a");

      const recvTarget = [...recvOptions].find(opt =>
         opt.innerText.trim().toLowerCase() === "material purchase"
      );

      if (!recvTarget) return;

      recvTarget.click();
      await wait(800);

      // ===============================
      // 3️⃣ OPEN GATE ENTRY
      // ===============================

      document.querySelector("#gate_record").click();
      await wait(1500);

      // ===============================
      // 4️⃣ SELECT GATE ENTRY
      // ===============================

      const gateValue = prompt("Enter Gate Entry Number:");
      if (!gateValue) return;

      const gateDropdown = document.querySelector("#gate_entry_id");
      gateDropdown.querySelector(".dropdown-toggle").click();
      await wait(100);

      let searchInput;
      for (let i = 0; i < 15; i++) {
         searchInput = gateDropdown.querySelector(".custom-select-search input");
         if (searchInput) break;
         await wait(500);
      }

      if (!searchInput) return;

      const gateScope = angular.element(searchInput).scope();
      gateScope.$apply(function () {
         gateScope.searchTerm = gateValue;
      });

      await wait(500);

      const gateOptions = gateDropdown.querySelectorAll("ul li a");

      let match = [...gateOptions].find(opt =>
         opt.innerText.toLowerCase().includes(gateValue.toLowerCase())
      );

      if (!match && gateOptions.length) {
         match = gateOptions[0];
      }

      if (!match) return;

      match.click();
      await wait(800);

      // ===============================
      // 5️⃣ SELECT ALL GRID
      // ===============================

      const buttons = document.querySelectorAll(
         ".ui-grid-selection-row-header-buttons"
      );

      if (buttons.length >= 3) {
         const gridScope = angular.element(buttons[2]).scope();
         gridScope.$apply(function () {
            gridScope.headerButtonClick();
         });
      }

      await wait(500);

      // ===============================
      // 6️⃣ CLICK OK & CLOSE
      // ===============================
      await waitForIdle()
      let okBtn;
      for (let i = 0; i < 20; i++) {
         okBtn = document.querySelector("#sub_screen_ok");
         if (okBtn && !okBtn.disabled) break;
         await wait(100);
      }

      if (!okBtn) return;

      okBtn.click();
      await wait(1500);

      await new Promise(resolve => {
         if (document.readyState === "complete") resolve();
         else window.addEventListener("load", resolve);
      });
      await waitForIdle()
      // ===============================
      // 7️⃣ VALIDATION
      // ===============================

      const qtyInputRaw = prompt("Enter Expected Quantity (you can use +, -, *, /):");

      const expectedQty = evaluateExpression(qtyInputRaw);

      if (expectedQty === null || isNaN(expectedQty)) {
         alert("Invalid quantity input");
         return;
      }
      const amountInput = prompt("Enter Expected Amount:");
      if (!qtyInputRaw || !amountInput) return;

      const expectedAmount = parseFloat(amountInput);

      const footer = document.querySelector(".settotalfooter");
      const receiveField = document.querySelector("#receive_amount");
      const billField = document.querySelector("#bill_amount");

      if (!footer || !receiveField || !billField) {
         showAlert("Validation fields not found.", "error");
         return;
      }

      const actualQty = parseFloat(
         footer.innerText.match(/([\d\.]+)/)[1]
      );

      const receiveAmount = parseFloat(receiveField.value.replace(/,/g, ""));
      const billAmount = parseFloat(billField.value.replace(/,/g, ""));

      const qtyValid = Math.abs(expectedQty - actualQty) < 0.001;

      function isWithinFloorCeil(actual) {
         const min = Math.floor(actual);
         const max = Math.ceil(actual);
         return expectedAmount >= min && expectedAmount <= max;
      }

      const receiveValid = isWithinFloorCeil(receiveAmount);
      const billValid = isWithinFloorCeil(billAmount);

      const allValid = qtyValid && receiveValid && billValid;

      showAlert(
         `Qty:${qtyValid ? "✔" : "✖"} | Rec:${receiveValid ? "✔" : "✖"} | Bill:${billValid ? "✔" : "✖"}`,
         allValid ? "success" : "error",
         7000
      );
      async function runAddChargesScript() {

         function wait(ms) {
            return new Promise(r => setTimeout(r, ms));
         }

         var addBtn = document.querySelector("#detail_collapsible_panel_open_popup_receive_other_charges_dt");

         if (!addBtn) {
            console.log("Add Other Charges button not found.");
            return false;
         }

         addBtn.click();
         console.log("Opening Additional Charges modal...");
         await wait(400);

         var typeDropdownList = document.querySelectorAll("#account_id");
         var typeDropdown = typeDropdownList[typeDropdownList.length - 1];

         if (!typeDropdown) {
            console.log("Charge Type dropdown not found.");
            return false;
         }

         var modal = typeDropdown.closest(".modal-content");

         const chargeAliasMap = {
            "bc": "BANK CHARGES",
            "fc": "FREIGHT AND CARTAGE",
            "disc": "DISCOUNT"
         };

         var userInput = prompt("Enter Charge Type Alias (bc, fcn, discn etc):");
         if (!userInput) return false;

         var cleaned = userInput.trim().toLowerCase();
         var isNotTaxable = cleaned.endsWith("n");

         if (isNotTaxable) {
            cleaned = cleaned.slice(0, -1);
         }

         var chargeType = chargeAliasMap[cleaned] || cleaned.toUpperCase();

         var amount = prompt("Enter Charge Amount:");
         if (!amount) return false;

         typeDropdown.querySelector(".dropdown-toggle").click();
         await wait(200);

         var searchInput = typeDropdown.querySelector("input[type='text']");
         if (searchInput) {
            var searchScope = angular.element(searchInput).scope();
            searchScope.$apply(function () {
               searchScope.searchTerm = chargeType;
            });
         }

         await wait(500);

         var options = typeDropdown.querySelectorAll("ul li a");

         var target = [...options].find(opt =>
            opt.innerText.trim().toLowerCase() === chargeType.toLowerCase()
         );

         if (!target) {
            console.log("Charge type not found in dropdown.");
            return false;
         }

         target.click();
         await wait(200);

         var amountInputs = modal.querySelectorAll("#charge_value");
         var amountInput = amountInputs[amountInputs.length - 1];
         var scope = angular.element(amountInput).scope();

         scope.$apply(function () {
            scope.popup_model.charge_value = amount;
         });

         await wait(200);

         if (isNotTaxable) {

            var taxDropdownList = modal.querySelectorAll("#is_tax");
            var taxDropdown = taxDropdownList[taxDropdownList.length - 1];

            taxDropdown.querySelector(".dropdown-toggle").click();
            await wait(200);

            var taxOptions = taxDropdown.querySelectorAll("ul li a");

            var noOption = [...taxOptions].find(opt =>
               opt.innerText.trim().toLowerCase() === "no"
            );

            if (noOption) noOption.click();

            await wait(200);
         }

         var buttons = modal.querySelectorAll("button");

         var okCloseBtn = [...buttons].find(btn =>
            btn.innerText.trim().toLowerCase() === "ok & close"
         );

         if (!okCloseBtn) {
            console.log("Ok & Close button not found.");
            return false;
         }

         okCloseBtn.click();

         console.log("Additional Charge added successfully.");
         return true;
      }

      if (!allValid) {

         await wait(800);
         await new Promise(resolve => {
            if (document.readyState === "complete") resolve();
            else window.addEventListener("load", resolve);
         });
         const decision = prompt(
            "Values are not matching.\nWould You Want to Add Charges?\nType YES to continue:"
         );

         const valid = ["y", "ys", "yes"];

         if (!decision || !valid.includes(decision.trim().toLowerCase())) {
            showAlert("Process stopped due to mismatch.", "error", 5000);
            return;
         } else {
            showAlert("Opening Add Charges...", "success", 4000);
         }
         const added = await runAddChargesScript();

         if (!added) {
            showAlert("Charges were not added.", "error", 5000);
            return;
         }

         // ✅ WAIT FOR SYSTEM TO RECALCULATE
         await wait(1200);

         // 🔁 RE-VALIDATE AGAIN
         const newReceiveAmount = parseFloat(
            document.querySelector("#receive_amount").value.replace(/,/g, "")
         );

         const newBillAmount = parseFloat(
            document.querySelector("#bill_amount").value.replace(/,/g, "")
         );

         const newReceiveValid = isWithinFloorCeil(newReceiveAmount);
         const newBillValid = isWithinFloorCeil(newBillAmount);

         const newAllValid = newReceiveValid && newBillValid;

         showAlert(
            `After Charges → Rec:${newReceiveValid ? "✔" : "✖"} | Bill:${newBillValid ? "✔" : "✖"}`,
            newAllValid ? "success" : "error",
            6000
         );

         if (!newAllValid) {
            showAlert("Still not matching. Stopping process.", "error", 6000);
            return;
         }

         // ✅ If valid now → DO NOT RETURN
         showAlert("Amounts matched. Continuing...", "success", 4000);
      }


      // ===============================
      // 🔹 SELECT STORE
      // ===============================

      const storeDropdown = document.querySelector("#stores");
      if (!storeDropdown) {
         showAlert("Store dropdown not found.", "error");
         return;
      }

      storeDropdown.querySelector(".dropdown-toggle").click();
      await wait(200);

      const storeOptions = storeDropdown.querySelectorAll("ul li a");

      const storeMatch = [...storeOptions].find(opt =>
         opt.innerText.trim().toLowerCase() === "acc store c-122"
      );

      if (!storeMatch) {
         showAlert("ACC. STORE C-122 not found.", "error");
         return;
      }

      storeMatch.click();
      await wait(100);

      // ===============================
      // DATA MATCHING SCRIPT
      applyBalanceRemarkLogic();
      // ===============================


      // ===============================
      // 🔹 CLICK APPLY
      // ===============================

      let applyBtn;
      for (let i = 0; i < 15; i++) {
         applyBtn = document.querySelector("#apply");
         if (applyBtn && !applyBtn.disabled) break;
         await wait(100);
      }

      if (!applyBtn) {
         showAlert("Apply button not found.", "error");
         return;
      }

      applyBtn.click();
      await wait(1000);
      await new Promise(resolve => {
         if (document.readyState === "complete") resolve();
         else window.addEventListener("load", resolve);
      });
      // ===============================
      // 8️⃣ ASK USER TO SAVE
      // ===============================

      const saveDecision = prompt("All validations passed.\nType YES / Y / OK to Save:");

      if (!saveDecision) {
         showAlert("Save Cancelled by User.", "error", 4000);
         return;
      }

      const normalized = saveDecision.trim().toLowerCase();

      const acceptedInputs = ["yes", "y", "ok", "okay"];

      if (!acceptedInputs.includes(normalized)) {
         showAlert("Save Cancelled by User.", "error", 4000);
         return;
      }

      // ===============================
      // 9️⃣ CLICK SAVE
      // ===============================

      let saveBtn;
      for (let i = 0; i < 20; i++) {
         saveBtn = document.querySelector("#Save");
         if (saveBtn && !saveBtn.disabled) break;
         await wait(100);
      }

      if (!saveBtn) return;

      saveBtn.click();
      showAlert("Record Saved Successfully ✔", "success", 6000);

   })();

}

// ===============================
// EXECUTION
// ===============================

// Run script immediately
initScript();

// Periodically check for the #New button and bind it once it appears
const bindInterval = setInterval(() => {
   if (document.querySelector("#New")) {
      bindNewButton();
      clearInterval(bindInterval);
   }
}, 1000);