(function addSelectAllButton() {
    // Avoid adding duplicate buttons
    if (document.getElementById("select-all-rows-btn")) return;

    const btn = document.createElement("button");
    btn.id = "select-all-rows-btn";
    btn.textContent = "Select All Rows";
    Object.assign(btn.style, {
        position: "fixed",
        top: "16px",
        right: "16px",
        zIndex: "999999",
        padding: "10px 16px",
        background: "#2563eb",
        color: "#fff",
        border: "none",
        borderRadius: "6px",
        fontSize: "14px",
        fontWeight: "600",
        cursor: "pointer",
        boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
    });

    async function selectAllUiGridRows(root = document, options = {}) {
        const { step = 400, scrollDelay = 180, maxIterations = 500 } = options;
        const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        const viewports = root.querySelectorAll(
            ".ui-grid-render-container-left .ui-grid-viewport"
        );
        const viewport1 = viewports[1];

        if (!viewport1) {
            console.error("❌ viewport nth(1) not found");
            return;
        }

        const selectVisibleCheckboxes = () => {
            const checkboxes = root.querySelectorAll(
                ".ui-grid-render-container-left .ui-grid-viewport .ui-grid-canvas .ui-grid-selection-row-header-buttons"
            );
            for (const cb of checkboxes) {
                if (!cb.classList.contains("ui-grid-row-selected")) {
                    cb.click();
                }
            }
        };

        let iterations = 0;
        while (iterations < maxIterations) {
            selectVisibleCheckboxes();
            const previousScrollTop = viewport1.scrollTop;
            viewport1.scrollTop += step;
            await wait(scrollDelay);
            if (viewport1.scrollTop === previousScrollTop) break;
            iterations++;
        }

        if (iterations >= maxIterations) {
            console.warn("⚠️ Hit max iteration cap — scroll may not have reached the end.");
        }

        selectVisibleCheckboxes();
        console.log("🎉 All rows selected successfully.");
    }

    btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = "Selecting…";
        try {
            await selectAllUiGridRows(document);
            btn.textContent = "✅ Done";
        } catch (err) {
            console.error(err);
            btn.textContent = "❌ Error";
        } finally {
            setTimeout(() => {
                btn.textContent = "Select All Rows";
                btn.disabled = false;
            }, 1500);
        }
    });

    document.body.appendChild(btn);
})();