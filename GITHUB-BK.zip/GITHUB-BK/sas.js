
(async function () {
    // Only run on the intended page.
    if (
        !location.hostname.endsWith(".bluekaktus.com") ||
        location.pathname !== "/Dashboard/Index" ||
        !location.hash.startsWith("#/")
    ) {
        console.log("Script not running: unsupported page.");
        return;
    }
    (function () {
        "use strict";

        // Restore context menu and text selection
        function enableContextMenu() {
            document.oncontextmenu = null;
            document.onselectstart = null;
            document.ondragstart = null;

            // Remove common inline handlers
            document.onkeydown = null;
            document.onkeyup = null;
            document.onkeypress = null;

            window.onkeydown = null;
            window.onkeyup = null;
            window.onkeypress = null;

            // Prevent later keydown listeners from seeing F12
            window.addEventListener(
                "keydown",
                e => {
                    if (e.key === "F12" || e.keyCode === 123) {
                        e.stopImmediatePropagation();
                    }
                },
                true
            );
            document.documentElement.style.userSelect = "text";
            document.body && (document.body.style.userSelect = "text");

            window.addEventListener(
                "contextmenu",
                e => e.stopImmediatePropagation(),
                true
            );
        }

        enableContextMenu();

        document.addEventListener("DOMContentLoaded", enableContextMenu);

        // ... your existing loader code ...
    })();
    async function verifyKey() {
        const STORAGE = "bk_auth_hash";
        let hash = localStorage.getItem(STORAGE);

        if (!hash) {
            const key = prompt("Enter Access Key:");
            if (!key) return false;

            const buf = await crypto.subtle.digest(
                "SHA-256",
                new TextEncoder().encode(key)
            );

            hash = [...new Uint8Array(buf)]
                .map(b => b.toString(16).padStart(2, "0"))
                .join("");
        }

        const res = await fetch(
            "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/HASH-KEY/keys.json?v=" + Date.now(),
            { cache: "no-store" }
        );

        if (!res.ok) {
            alert("Key server unreachable");
            return false;
        }

        const db = await res.json();
        const today = new Date();

        const valid = db.keys.find(k =>
            k.hash === hash &&
            k.active &&
            new Date(k.expiry) >= today
        );

        if (!valid) {
            localStorage.removeItem(STORAGE);
            alert("Access revoked or expired");
            return false;
        }

        localStorage.setItem(STORAGE, hash);
        return true;
    }

    if (!(await verifyKey())) return;

    // Place your own authorized debugging code here.
    angular.element(document.body)
        .injector()
        .get('$rootScope')
        .UserDetails.isSuperUser = true;

    console.log("Verification successful.");
})();