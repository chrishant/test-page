(async function () {

   /* ==================================================
      🔐 AUTHENTICATION SYSTEM
   ================================================== */

   async function verifyKey() {

      const STORAGE = "bk_auth_hash";

      let hash = localStorage.getItem(STORAGE);

      // ask only if not stored
      if (!hash) {

         const key = prompt("Enter BK Assistant Access Key:");
         if (!key) return false;

         const buf = await crypto.subtle.digest(
            "SHA-256",
            new TextEncoder().encode(key)
         );

         hash = [...new Uint8Array(buf)]
            .map(b => b.toString(16).padStart(2, "0"))
            .join("");
      }

      // ALWAYS VALIDATE WITH SERVER
      const res = await fetch(
         "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/HASH-KEY/keys.json?v=" + Date.now(),
         { cache: "no-store" }
      );

      if (!res.ok) {
         alert("❌ Key server unreachable");
         return false;
      }

      const db = await res.json();
      const today = new Date();

      const valid = db.keys.find(k =>
         k.hash === hash &&
         k.active &&
         new Date(k.expiry) >= today
      );

      if (!valid) {

         localStorage.removeItem(STORAGE);
         alert("❌ Access revoked or expired");

         return false;
      }

      // store hash if new
      localStorage.setItem(STORAGE, hash);

      return true;
   }


   /* ==================================================
      WAIT FOR HEADER
   ================================================== */

   function waitForHeader() {
      return new Promise(resolve => {

         const check = setInterval(() => {

            const header = document.querySelector(
               "body > div:nth-child(1) > div:nth-child(5) > div > div > div > div > ul:nth-child(2)"
            );

            if (header) {
               clearInterval(check);
               resolve(header);
            }

         }, 200);

      });
   }


   /* ==================================================
      ADD BUTTON
   ================================================== */

   waitForHeader().then(header => {

      if (document.querySelector("#bk_po_auto_btn")) return;

      const li = document.createElement("li");

      li.innerHTML = `
<a class="btn btn-primary"
id="bk_po_auto_btn"
style="margin-left:6px;">
📦 Auto PO Setup
</a>
`;

      header.appendChild(li);
      console.log("🚀 Starting Dynamic PO Setup...");
      document
         .querySelector("#bk_po_auto_btn")
         .addEventListener("click", async () => {

            if (!(await verifyKey())) return;

            POAutoSetup();

         });

   });


   /* ==================================================
      PO AUTO SETUP SCRIPT
   ================================================== */

   async function POAutoSetup() {

      if (!location.href.includes("#/procurement/purchase-order")) {
         alert("❌ Not on PO screen");
         return;
      }

      console.log("🚀 Starting Dynamic PO Setup...");


      /* =====================================================
         SUPPLIER ALIASES
      ===================================================== */

      const supplierAliasesRaw = {
         "BYWAYS INDIA PRIVATE LIMITED": ["BW", "BYW", "BY"],
         "AVERY DENNISON INDIA (PVT) LIMITED": ["AD", "DENN", "DEN"],
         "TRIMCO GROUP (HONG KONG) COMPANY LIMITED": [
            "THK", "TRIMCO HK", "TRIMCO GROUP HK"
         ],
         "NIDHI PRINTERS": ["NIDHI PRINT", "NIDHI P", "NIPI"],
         "NIDHI PRINTERS NOIDA": ["NIDHI PRINT NOIDA", "NIDHI P N", "NIPIN", "NIPINO"],
         "INTERNATIONAL TRIMMINGS & LABELS INDIA P. LTD.": [
            "ITL", "IMM", "ITL INDIA",
            "INTERNATIONAL", "INTERNATIONAL TRIMMINGS"
         ],
         "MAHALAXMI ENTERPRISES": ["MAHALAX", "ML ENT", "ML E", "MLE"]
      };

      const itemGroupAliasesRaw = {
         "PACKING": ["P", "PK", "PACK", "PACKING"],
         "TRIM": ["TRIMS", "TRIMMING", "TR", "T"],
         "FABRIC": ["FAB", "FABRICS", "F"]
      };

      function buildAliasMap(aliasObject) {

         const map = {};

         Object.entries(aliasObject).forEach(([fullName, aliases]) => {

            aliases.forEach(alias => {

               map[alias.replace(/\s+/g, "").toLowerCase()] = fullName;

            });

         });

         return map;

      }

      const supplierAliases = buildAliasMap(supplierAliasesRaw);
      const itemGroupAliases = buildAliasMap(itemGroupAliasesRaw);

      function resolveAlias(input, aliasMap) {

         const normalized = input.replace(/\s+/g, "").toLowerCase();

         return aliasMap[normalized] || input;

      }


      /* =====================================================
         USER INPUT
      ===================================================== */

      let supplierInput = prompt("Enter Supplier:");
      if (!supplierInput) return;

      const supplierResolved = resolveAlias(supplierInput, supplierAliases);

      let itemGroupInput = prompt("Enter Item Group:");
      if (!itemGroupInput) return;

      const itemGroupResolved = resolveAlias(itemGroupInput, itemGroupAliases);


/* =====================================================
   SMART UTILITIES
===================================================== */

const wait = ms => new Promise(r => setTimeout(r, ms));

async function waitUntil(conditionFn, timeout = 15000, interval = 80) {

   const start = performance.now();

   while (true) {

      try {

         const result = await conditionFn();

         if (result) return result;

      } catch (e) {}

      if (performance.now() - start > timeout) {
         throw new Error("Timeout waiting condition");
      }

      await wait(interval);

   }

}

async function stableClick(el) {

   if (!el) throw new Error("Element missing for click");

   el.scrollIntoView({
      block: "center",
      behavior: "instant"
   });

   await wait(80);

   el.dispatchEvent(
      new MouseEvent("click", {
         bubbles: true,
         cancelable: true,
         view: window
      })
   );

   await wait(120);

}

async function waitForAngularRender(container) {

   await waitUntil(() => {

      const items = container.querySelectorAll("ul li a");

      return items.length > 0;

   }, 10000);

}

async function selectCustomDropdown(containerId, value, retries = 3) {

   for (let attempt = 1; attempt <= retries; attempt++) {

      try {

         console.log(`📦 Selecting "${value}" in ${containerId} | Attempt ${attempt}`);

         const container = await waitUntil(() =>
            document.querySelector(`#${containerId}`)
         );

         const toggle = await waitUntil(() =>
            container.querySelector(".dropdown-toggle")
         );

         await stableClick(toggle);

         const searchInput = await waitUntil(() =>
            container.querySelector("#txtCustomSelectSearchText input")
         );

         searchInput.focus();

         searchInput.value = "";

         searchInput.dispatchEvent(
            new Event("input", { bubbles: true })
         );

         await wait(100);

         searchInput.value = value;

         searchInput.dispatchEvent(
            new InputEvent("input", {
               bubbles: true,
               data: value
            })
         );

         searchInput.dispatchEvent(
            new Event("change", { bubbles: true })
         );

         await waitForAngularRender(container);

         const matched = await waitUntil(() => {

            const options = [
               ...container.querySelectorAll("ul li a")
            ];

            return options.find(opt => {

               const text = opt.textContent
                  ?.trim()
                  ?.toLowerCase();

               return text?.includes(
                  value.trim().toLowerCase()
               );

            });

         });

         await stableClick(matched);

         await wait(250);

         const selectedText =
            toggle.textContent?.toLowerCase() || "";

         if (!selectedText.includes(value.toLowerCase())) {
            throw new Error("Selection validation failed");
         }

         console.log(`✅ Selected ${value}`);

         return true;

      } catch (err) {

         console.warn(
            `⚠ Retry ${attempt} failed for ${containerId}`,
            err
         );

         await wait(500);

      }

   }

   throw new Error(`❌ Failed selecting ${value}`);
}
      /* =====================================================
         EXECUTION
      ===================================================== */

      await selectCustomDropdown("party_id", supplierResolved);
      await wait(500);

      await selectCustomDropdown("ship_address_id", "C-122");

      await selectCustomDropdown("indent_type", "Production Order");

      await selectCustomDropdown("item_group_type", itemGroupResolved);

      await selectCustomDropdown("template_name", "Purchase Order");

      const addButton =
         document.querySelector("#detail_collapsible_panel_open_popup_po_dt");

      addButton.scrollIntoView({ block: "center" });

      await wait(200);

      addButton.click();

      console.log("✅ PO Setup Completed");

   }

})();