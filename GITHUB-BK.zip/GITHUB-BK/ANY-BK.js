// ==UserScript==
// @name         BK Assistants Loader
// @match        *https://windeson.bluekaktus.com/Dashboard/Index#/*
// @run-at       document-idle
// ==/UserScript==

(function () {

   /* ==================================================
      ROUTE → SCRIPT MAP
   ================================================== */

   const routes = [

      {
         url: "#/procurement/purchase-order",
         script: "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/BK/po-dynamic.user.js"
      },

      {
         url: "#/procurement/receiving",
         script: "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/BK/receiving.user.js"
      },

      {
         url: "#/procurement/inspection",
         script: "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/BK/inspection-matpur-DySup.user.js"
      },

      {
         url: "#/order/bom",
         script: "https://raw.githubusercontent.com/chrishant/BK-ASSIST.user.scripts/main/BK/BOM-IMPORT.user.js"
      }

   ];


   /* ==================================================
      SCRIPT LOADER
   ================================================== */
   // ==UserScript==
   // @name         BK Assistants Loader
   // @match        https://windeson.bluekaktus.com/Dashboard/Index*
   // @run-at       document-start
   // ==/UserScript==

   (function () {
      "use strict";

      // Restore context menu and text selection
      function enableContextMenu() {
         document.oncontextmenu = null;
         document.onselectstart = null;
         document.ondragstart = null;

         // Remove common inline handlers
         document.onkeydown = null;
         document.onkeyup = null;
         document.onkeypress = null;

         window.onkeydown = null;
         window.onkeyup = null;
         window.onkeypress = null;

         // Prevent later keydown listeners from seeing F12
         window.addEventListener(
            "keydown",
            e => {
               if (e.key === "F12" || e.keyCode === 123) {
                  e.stopImmediatePropagation();
               }
            },
            true
         );
         document.documentElement.style.userSelect = "text";
         document.body && (document.body.style.userSelect = "text");

         window.addEventListener(
            "contextmenu",
            e => e.stopImmediatePropagation(),
            true
         );
      }

      enableContextMenu();

      document.addEventListener("DOMContentLoaded", enableContextMenu);

      // ... your existing loader code ...
   })();

   function loadScript(src) {

      fetch(src)
         .then(r => r.text())
         .then(code => {

            const s = document.createElement("script");

            s.textContent = code;

            document.documentElement.appendChild(s);

         })
         .catch(e => console.error("BK Loader error:", e));

   }


   /* ==================================================
      ROUTE DETECTION
   ================================================== */

   function detectRoute() {

      const current = location.href;

      for (const r of routes) {

         if (current.includes(r.url)) {

            loadScript(r.script);

            return;

         }

      }

   }

   detectRoute();


   /* ==================================================
      SPA NAVIGATION WATCHER
   ================================================== */

   let lastUrl = location.href;

   setInterval(() => {

      if (location.href !== lastUrl) {

         lastUrl = location.href;

         detectRoute();

      }

   }, 1000);

})();