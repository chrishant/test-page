const crypto = require("crypto");

function hash(key){
return crypto
.createHash("sha256")
.update(key)
.digest("hex");
}

console.log(hash("BKDEV-01"));